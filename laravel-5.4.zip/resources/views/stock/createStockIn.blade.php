@extends('layouts.app')
@section('title','Add Stock In')
@section('breadcrumb','Add Stock In')
@section('content')
@if ($errors->any())
<div class="alert alert-danger">
   <ul>
      @foreach ($errors->all() as $error)
      <li>{{ $error }}</li>
      @endforeach
   </ul>
</div>
<br />
@endif
<form method="post" action="{{url('/stock/createStockIn')}}">
   <div class="row">
      <div class="col-md-5">
         <div class="form-group">
            <input type="hidden" value="{{csrf_token()}}" name="_token" />
            <label for="name">Supplier Name:</label>
            <select name="supplier" class="form-control select2">
               <option value="">Select Supplier</option>
               @foreach($suppliers as $supplier)
               <option value="{{ $supplier->id}}">{{ $supplier->name}}</option>
               @endforeach
            </select>
         </div>
      </div>
      <div class="col-md-6">
         <div class="form-group">
            <br />
            <a href="{{url('/supplier/create')}}" class="btn btn-success btn-sm" style="margin-top:5px"><i class="fa fa-plus"></i> Add Supplier</a>
         </div>
      </div>
   </div>
   <div class="row">
      <div class="col-md-5">
         <div class="form-group">
            <label for="name">Check In Date:</label>
            <div class="input-group date">
               <div class="input-group-addon">
                  <i class="fa fa-calendar"></i>
               </div>
               <input type="text" class="form-control pull-right" id="datepicker">
            </div>
         </div>
      </div>
   </div>
   <div class="row">
      <div class="col-md-12">
         <h4><span class="heading">Add Items</span></h4>
         <div id="item_add">
            <div class="row">
               <div class="form-group col-md-3">
                  <label for="doc" class="text-normal m-bottom p-bottom-5">Item Name: </label><br>
                  <select class="form-control select2" id="item" name="item">
                     <option value="">Select Items</option>
                     @foreach($items as $item)
                     <option value="{{ $item->id}}">{{ $item->name}}</option>
                     @endforeach
                  </select>
                  <span id="item-error" style="color:#C51818; font-weight:bold"></span>
               </div>
               <div class="form-group col-md-3">
                  <label for="doc" class="text-normal m-bottom p-bottom-5">Qty: </label><br>
                  <input class="itemName form-control" style="width:250px" id="qty" name="qty" placeholder="Enter Qty" />
                  <span id="qty-error" style="color:#C51818; font-weight:bold"></span>
               </div>
               <div class="form-group col-md-3">
                  <label for="doc" class="text-normal m-bottom p-bottom-5">Price: </label><br>
                  <input class="itemName form-control" style="width:250px" id="price" name="price" placeholder="Enter Price" />
                  <span id="price-error" style="color:#C51818; font-weight:bold"></span>
               </div>
               <div class="form-group col-md-3"  id="addrow">
                  <label for="add-row" class="text-normal m-bottom p-bottom-5"></label><br />
                  <button class="add-row btn btn-primary" name="add-row" type="button" style="margin-top:5px">Add</button>
               </div>
               <!-- /form-group-->
            </div>
			 <div class="row">
			 <div class="col-md-12">
            <div class="table-responsive">
               <table id="dynamictable" class="table table-bordered table-striped" style="width:100%;">
                  <thead>
                     <tr class="btn-default">
                        <th></th>
                        <th>Item Name</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th></th>
                     </tr>
                  </thead>
                  <tbody>
                  </tbody>
               </table>
            </div>
            <input type="hidden" id="hdnCount" name="hdnCount">
            <button type="button" class="delete-row btn btn-sm btn-danger"><i class="fa fa-trash"></i> Delete Row</button>
			</div>
			</div>
         </div>
      </div>
   </div><br />
      <div class="row">
      <div class="col-md-12">
   <div class="form-group">
      <label for="description">Remarks:</label>
      <textarea type="text" class="form-control editor" id="remarks" name="remarks" placeholder="Enter 
         Remarks" autocomplete="off">
      </textarea>
   </div>
   </div>
   </div>
   <button type="submit" class="btn btn-primary">Stock In</button>
</form>
@endsection