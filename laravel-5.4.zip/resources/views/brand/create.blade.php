@extends('layouts.app')
@section('title','Add Brand')
@section('breadcrumb','Add Brand')
@section('content')

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div><br />
@endif
   
    <form method="post" action="{{url('/brand/create')}}">
        <div class="form-group">
            <input type="hidden" value="{{csrf_token()}}" name="_token" />
            <label for="name">Brand Name:</label>
            <input type="text" class="form-control" name="name" placeholder="Enter brand name" autocomplete="off"/>
        </div>
	
        <div class="form-group">
            <label for="description">Brand Description:</label>
            <textarea cols="5" rows="5" class="form-control editor" name="description" placeholder="Enter brand description" autocomplete="off"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
        </form>
 

@endsection