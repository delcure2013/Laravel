@extends('layouts.app')
@section('title','Brand List')
@section('breadcrumb','Brands')
@section('content')

	@if(\Session::has('success'))
        <div class="alert alert-success">
            {{\Session::get('success')}}
        </div>
    @endif
	@if ($errors->any())
		<div class="alert alert-danger">
			<ul>
				@foreach ($errors->all() as $error)
					<li>{{ $error }}</li>
				@endforeach
			</ul>
		</div><br />
	@endif
	<!--<button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addBrandModal">Add Brand</button>-->
	 <a href="{{url('/brand/create')}}" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Add Brand</a> 
    <table class="table table-striped table-bordered" id="brand_list" style="font-size:10pt">
        <thead>
            <tr>
			<th>Sr. No.</th>
              <th>Name</th>
              <th>Description</th>
              <th style="text-align:center">Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($brands as $brand)
            <tr>
			<td width="10%">{{$loop->iteration}}</td>
                <td width="30%">{{$brand->name}}</td>
                <td width="40%">{{$brand->description}}</td>
                <td width="20%" style="text-align:center">
				<form action="{{action('BrandController@destroy',$brand->id) }}" method="post">
				
               
			   <a href="{{action('BrandController@edit',$brand->id)}}" class="btn btn-primary btn-sm" alt="edit"  title="edit"><i class="fa fa-pencil"></i></a>
				  
					{{csrf_field()}}
					<input name="_method" type="hidden" value="DELETE">
					<button class="btn btn-danger btn-sm" type="submit" onclick="return confirm('Are you sure want to delete??')"  title="delete"><i class="fa fa-trash"></i></button>
				  </form>
				</td>
            </tr>
            @endforeach
        </tbody>
    </table>

{{ $brands->links() }}
@endsection


<script src="http://code.jquery.com/jquery-3.3.1.min.js"
      integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous">
</script>


<script>
$(document).ready(function() {
    $('#brand_list').DataTable( {
        "paging":   false
    } );
} );
</script>