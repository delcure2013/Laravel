@extends('layouts.app')
@section('title','Edit Unit')
@section('breadcrumb','Edit Unit')
@section('content')

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div><br />
@endif

    <form method="post" action="{{action('UnitController@update', $id)}}" >
        <div class="form-group">
            <input type="hidden" value="{{csrf_token()}}" name="_token" />
            <label for="name">Unit Name:</label>
            <input type="text" class="form-control" name="name" value='{{$unit->name}}' placeholder="Enter unit name" autocomplete="off"/>
        </div>
		
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea cols="5" rows="5" class="form-control" name="description" placeholder="Enter unit description" autocomplete="off">{{$unit->description}}</textarea>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        </form>
   
@endsection