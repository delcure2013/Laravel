@extends('layouts.app')
@section('title','Add Unit')
@section('breadcrumb','Add Unit')
@section('content')

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div><br />
@endif
   
    <form method="post" action="{{url('/unit/create')}}">
        <div class="form-group">
            <input type="hidden" value="{{csrf_token()}}" name="_token" />
            <label for="name">Unit Name:</label>
            <input type="text" class="form-control" name="name" placeholder="Enter unit name" autocomplete="off"/>
        </div>
		
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea cols="5" rows="5" class="form-control" name="description" placeholder="Enter unit description" autocomplete="off"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
        </form>
 

@endsection